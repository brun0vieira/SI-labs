:- dynamic prolog_functor/1.


:- dynamic prolog_functor/2.

prolog_functor(x_is_at,  0).
prolog_functor(x_moving, 0).
prolog_functor(y_moving, 0).
prolog_functor(z_moving, 0).

