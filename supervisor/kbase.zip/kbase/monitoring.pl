

/*
problemas, sintomas, solu��es



https://www.codepoc.io/blog/prolog/5060/prolog-program-of-medical-diagnosis-system-of-childhood-decease
doencas, sintomas, hipoteses

*/
